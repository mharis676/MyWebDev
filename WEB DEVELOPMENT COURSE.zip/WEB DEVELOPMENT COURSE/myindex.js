console.log("HY I AM HARIS");
let a=45;
if(a>35)
{
    console.log("You can Drive");
}
else
{
    console.log("You can't");
}