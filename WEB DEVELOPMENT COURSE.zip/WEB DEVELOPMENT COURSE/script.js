alert('Welcome to the website');
console.log('HY I AM CONSOLE');
console.log('HY I AM RUNNING');
// shown in console
var a=prompt("ENTER YOUR NUMBER");
console.log("YOUR NUMBER IS "+ a);
var isTrue=confirm("ARE YOU SURE YOU WANT TO LEAVE");
if(isTrue)
{
    console.log("Sucessfully Left");
}
else{

}
document.title='Welcome to the website';
// document.body.style.background='red';