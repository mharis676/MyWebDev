console.log("HY This is tutorial 55");
var a=5;
var b=6;
console.log(a+b+9);
console.log(typeof a,typeof b);
